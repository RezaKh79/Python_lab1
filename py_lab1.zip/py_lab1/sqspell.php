<?php
### This file is part of the dictionaries-common package.
### It has been automatically generated.
### DO NOT EDIT!
$SQSPELL_APP = array (
  'American English (aspell)' => 'aspell -a -d en_US   ',
  'British English (aspell)' => 'aspell -a -d en_GB   ',
  'Canadian English (aspell)' => 'aspell -a -d en_CA   ',
  'English (aspell)' => 'aspell -a -d en   '
);
